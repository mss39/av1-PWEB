<html>
    <?php
        if($_REQUEST)
            if($_REQUEST['sucesso'] == true)
                echo "Produto inserido com sucesso";
    ?>
    <h1>Cadastrar Usuario</h1>
    <form action="../index.php?classe=Usuario&metodo=save" method="POST">
        Nome: <input name="nome" required></input><br>
        Email: <input name="email" required></input><br>
        Senha: <input name="senha" type="password" required></input><br>
        <input type="submit"/>
    </form>
</html>