<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PWEB</title>
</head>
<body>
    <form action="../index.php?classe=Usuario&metodo=login" method="post">

        <label>Login:</label><input type="text" name="nome" id="nome"><br>
        <label>Senha:</label><input type="password" name="senha" id="senha"><br>
        <input type="submit" value="entrar">
    </form>
</body>
</html>
