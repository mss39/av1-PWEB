<?php
require_once 'model/Usuario.php';
require_once 'model/UsuarioDao.php';

class UsuarioController{
    private $usuario;
    private $usuarioDao;

    public function save(){
        $this->usuario = new Usuario();
        $this->usuarioDao = new UsuarioDao();   
        
        $this->usuario->setNome($_REQUEST['nome']);
        $this->usuario->setEmail($_REQUEST['email']);
        $this->usuario->setSenha($_REQUEST['senha']);
        if($this->usuarioDao->save($this->usuario)){
            $_REQUEST['sucesso'] = true;
            require_once 'views/login.php';
        }
    }

    public function login(){
        $login = $_REQUEST["nome"];
        $senha = $_REQUEST["senha"];
        $this->usuarioDao = new UsuarioDao();   
        $this->usuarioDao->login($login,$senha);
    }

}