<?php
require_once 'Database.php';

class UsuarioDao{
    private $conexao;

    function __construct(){
        $Database = new Database;
        $this->conexao = $Database->getConexao();
    }

    function save($produto){
        $stmt = $this->conexao->prepare("INSERT INTO usuarios (nome, email,	senha) VALUES (:nome, :email, :senha)");
        $stmt->bindValue(':nome', $produto->getNome());
        $stmt->bindValue(':email', $produto->getEmail());
        $stmt->bindValue(':senha', $produto->getSenha());
        return $stmt->execute();
    }

    function list(){
        $sql = "SELECT * FROM usuarios";
        $stmt = $this->conexao->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    function login($login,$senha){
        $query_usuario = "SELECT id, nome, senha
        FROM usuarios 
        WHERE nome = :usuario
        AND senha = :senha
        LIMIT 1";
        $result_usuario = $this->conexao->prepare($query_usuario);
        $result_usuario->bindParam(':usuario', $login, PDO::PARAM_STR);
        $result_usuario->bindParam(':senha', $senha, PDO::PARAM_STR);
        $result_usuario->execute();

        if(($result_usuario) && ($result_usuario->rowCount() != 0)){
            echo"<script language='javascript' type='text/javascript'>
            alert('logado porra');window.location
            .href='login.html';</script>";
            die();
        }
        else{
            echo"<script language='javascript' type='text/javascript'>
            alert('Login incorreto');window.location
            .href='views/login.php';</script>";
        }
    }


}